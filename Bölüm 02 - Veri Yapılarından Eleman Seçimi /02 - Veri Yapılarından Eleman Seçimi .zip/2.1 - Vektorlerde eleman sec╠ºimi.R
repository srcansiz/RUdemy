
x <- c('A' , 'B' , 'C')

# Birinci Eleman Seçimi 
x[1]

# İkinci Eleman Seçimi
x[2]

y <- c(1,2,3,4,5,6,7,8,9,10)

# 1 ve 3 arasındaki elemanlar
y[1:3]
y[4:9]
y[5:8]

y[c(5,6,7,8)]

t <- c(11,12,13,29,25,29,30,31,32)
t[c(4,8,9)]
t[c(4,8,15)]

t[c(1 , 2, 3)]
t[3:8]

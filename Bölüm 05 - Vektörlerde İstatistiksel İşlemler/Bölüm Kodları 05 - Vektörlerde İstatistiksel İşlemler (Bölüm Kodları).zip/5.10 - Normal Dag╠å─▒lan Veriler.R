
rnorm(100)

r <- rnorm(100)
length(r)


hist(r)

r1 <- rnorm(30 , mean = 10 , sd = 3)
r1
hist(r1)


as.Date()

# 2012-01-01

as.POSIXct()
as.POSIXlt()

seq(from , to , by = 15)

strptime()
chron()

12/12/212

weekdays()
months()

sessionInfo()

Sys.setlocale('LC_TIME' , 'tr_TR.UTF-8')



# f(x , y) = x2 + 4x + 5y


toplama <- function(x , y){
  
      result = x + y
      
      return(result)
  
}

toplama(12,17)



bolme <- function(x , y){
  
      return(x/y)
  
}

bolme(16 , 4)


myfunction <- function(x , y ){
  
        t = x + y
        b = x/y
        z = x*y
        
        result = (t + b)/z
        
        return(result)
}

myfunction(15,30)



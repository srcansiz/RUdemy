

x <- list(11,12,13)

# Eleman değiştirme
x[[2]] <- 15
x


# YEni elaman eklemede

x[4] <- 33
x

x[5] <- 34
x

x[[6]] <- 35
x

x[[7]] <- c(11,12,13,14)
x

x[8] <- c(11,12,13,14)
x

x[[8]] <- c(11,12,13,14)
x

x[[15]] <- 15
x

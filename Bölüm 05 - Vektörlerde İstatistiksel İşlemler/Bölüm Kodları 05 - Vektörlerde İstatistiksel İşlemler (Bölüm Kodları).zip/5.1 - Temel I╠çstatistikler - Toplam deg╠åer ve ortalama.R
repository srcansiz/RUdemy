

x <- c(23,45,67,43,56)

# N n 

length(x)

sum(x)

x[1] + x[2] + x[3] + x[4] + x[5]

ort <- sum(x) / length(x)
ort

#Toplam için
sum(x)

# ORtalama
mean(x)


# Uzunluj Eleman Saysı
length(x)




x = 5
y = 10
print(x)
print(x ,y) # y'i yazdırmaz

print(x);print(y)

cat(x , ' -> ' , y , 5 ,3)
t <- cat(x , ' -> ' , y , 5 ,3) # T ye atama işlemi yapılamaz

cat( x , ' eşittir :' , y , '\n' , 'Alt satıra geçtim')


# Paste
paste(x , y , ' Değerli')

c <- paste(x , y , ' Değerli')
class(c)
c

paste0(x , y , 'D')
paste(x , y , ' Değerli \n sadasdasd')

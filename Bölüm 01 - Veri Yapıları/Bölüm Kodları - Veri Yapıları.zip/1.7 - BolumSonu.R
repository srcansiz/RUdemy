
# Vektorler

x <- c(1,2,3,4)

# Listeler

l <- list(1,2,3)
l1 <- list('a' = 1 , 'b' = 2)
l2 <- list(1 ,2 ,3 ,c(12,13,14))

# Data Frame 
df <- data.frame('a' = c(1,2,3,4) , 'b' = c(1,2,3,4))

# Matris
m <- matrix(c(1,2,3,4) , nrow=2 , ncol = 2)

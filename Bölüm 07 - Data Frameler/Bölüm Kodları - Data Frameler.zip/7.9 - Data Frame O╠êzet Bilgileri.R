View(iris)

summary(iris)

View(summary(iris))
str(iris)

head(iris)

iris[10:15 , ]


?head

head(iris , n = 5)
tail(iris , n = 15)

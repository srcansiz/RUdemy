

### Neural Networks - Yapay Sinir Ağları

install.packages("neuralnet")
library(neuralnet)


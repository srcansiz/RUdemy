
x <- c(12,23,45,56)
y <- c('A' , 'B' , 'C')
f <- factor(c('D','F' , 'G'))
l <- c(T,F,T,F,TRUE)

is.numeric(x)
is.integer(x)
is.character(y)
is.factor(f)
is.logical(l)

is.logical(x)
is.factor(y)
is.character(y)

class(y)
class(x)
class(f)
class(l)

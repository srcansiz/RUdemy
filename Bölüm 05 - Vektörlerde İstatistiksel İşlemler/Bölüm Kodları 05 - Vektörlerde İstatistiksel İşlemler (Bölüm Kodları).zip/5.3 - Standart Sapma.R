
x <- c(12,34,56,34,23,45)

length(x)

?sd
mean(x)
sd(x)

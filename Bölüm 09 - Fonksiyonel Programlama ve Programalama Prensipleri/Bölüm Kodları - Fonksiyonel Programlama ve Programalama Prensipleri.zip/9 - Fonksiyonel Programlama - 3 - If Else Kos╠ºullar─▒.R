
5 == 5

if(5 == 5){
  print('Doğru')
}

if(5 == 4){
  print('Doğru')
}


if(5 == 4){
  print('Doğru')
}else{
  print('Yanlış')
}

if(5 > 3){
  print('Doğru')
}

x = ''

if( 5 < 3){
  x = paste('5 3 ten büyüktür')
}else{
  x = paste('5 3 ten büyük değildir')
}
x



x <- c(12,14,10,11,13,17,16)

length(x)

sd1 <- sd(x)
vr1 <- sd(x)**2
sd1
vr1


# Varyans hesaplama fonksiyonu
var(x)

# Standartsapmanın karesi ile de hesaplanır
sd(x)**2


y <- c(12,25,60,56,35,24,45)
length(y)

sd2 <- sd(y)
vr2 <- var(y)

sd1;vr1;sd2;vr2



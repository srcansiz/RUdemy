# Matrisler 


x = c(1,2,3,4)

matrix(x , nrow = 2 , ncol=2 )
matrix(x , nrow=2 , ncol=2 , byrow=TRUE)


y = c(1,2,3,4,5,6,7,8)

matrix(y , nrow = 2 , ncol=4)
matrix(y , nrow = 4 , ncol=2)


matrix(x , nrow = 4 , ncol = 4)
matrix(x , nrow = 4 , ncol = 4 , byrow = T)


matrix(x , nrow = 5 , ncol = 5)

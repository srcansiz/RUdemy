
x = 5

y = c(1,2,3,4,5)
y

z <- c(10,20,30,40) 
z

## hatalı Kullanım
c(10,20,30,40) <- z


t <- c("A" , 'D' , 'F' , "D")
t


e <- c("A" , "B" , 2,3,4, "D")
e


# Hatalı kullanım 
c(34,45, , 45,67)


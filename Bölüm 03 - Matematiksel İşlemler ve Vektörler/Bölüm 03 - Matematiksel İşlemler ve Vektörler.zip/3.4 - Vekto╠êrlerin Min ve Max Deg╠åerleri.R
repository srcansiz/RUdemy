
x <- c(12,34,23,11,4,5,78)

# Minimum Değer 
min(x)

# Maximum Değer
max(x)

y <- c(-1,-10,-19 , 0 , 3,67,45)

min(y)
max(y)
t <- c(-1,-10,-19)
min(t)
max(t)

# İşlem önceliği önemlidir
(min(t) + max(t)) / min(t)
min(t) + max(t) / min(t)

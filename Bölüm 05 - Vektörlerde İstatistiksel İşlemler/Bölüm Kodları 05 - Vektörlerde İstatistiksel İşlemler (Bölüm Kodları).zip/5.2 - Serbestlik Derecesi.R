
x <- c(1,2,3,4,5)

sd <- length(x) -1 
sd

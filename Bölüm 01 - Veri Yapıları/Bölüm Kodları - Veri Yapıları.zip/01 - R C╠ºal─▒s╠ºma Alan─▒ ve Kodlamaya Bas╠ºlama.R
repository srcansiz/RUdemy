

## Kodlamaya Başlama


10001
5

5 + 5  # Toplama İşareti
# Toplama İşarte



x = 5
y = 10

5 + 10

x + y
x / y
x * y

z = 20

x - z






